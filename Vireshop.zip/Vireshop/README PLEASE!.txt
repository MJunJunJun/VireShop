This Application is not for mobile phone.
Please instal this application to your Occulus HMD VR.
